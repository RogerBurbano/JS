function sumar(numero1, numero2) {
	resultado = numero1 + numero2;
	return resultado;
}

let sumador1 = parseInt(prompt("insertar numero1:"));
let sumador2 = parseInt(prompt("insertar numero2:"));
alert(sumar(sumador1, sumador2));
