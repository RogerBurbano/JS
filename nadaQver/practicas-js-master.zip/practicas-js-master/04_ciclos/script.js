//ciclo WHILE

let number;
while (number != 8) {
	number = parseInt(prompt("Adivina el numero. Ayuda: es del 1 al 10"));
	alert("el numero " + number + " no es el correcto. vuelve a intentarlo.");
}
