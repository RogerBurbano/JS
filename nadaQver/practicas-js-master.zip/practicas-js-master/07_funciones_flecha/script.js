const suma = (a, b) => {
	return a + b;
};
//si es una funcion de una sola linea con retorno podemos evitar escribir el cuerpo.
const resta = (a, b) => a - b;
alert(suma(15, 20));
alert(resta(20, 5));
